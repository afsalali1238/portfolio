# forthe.tech brand kit · v1.0 · 21 October 2026

Everything needed to put forthe.tech on a page, a post or a slide. Start with
`05-guidelines/forthe.tech-brand-sheet.pdf`: it's the whole brand on one page.

The editable versions of every template live on the design canvas
("forthe.tech — logo & brand guidelines", page "Brand kit"). Change the text there, then export.

## 01-logo

| Folder | What's in it |
|---|---|
| `svg/` | Every logo as vector. `lockup` = mark + name, `stacked` = mark over name, `wordmark` = name only, `mark` = symbol only. `ink` files go on light grounds, `paper` files on dark. `32cut` and `16cut` are the small-size drawings. The name is outlined, so no font is needed. |
| `png/` | Transparent PNGs: lockups at 1200 and 2400 px wide, marks at 128–1024 px, small cuts at 32 and 16 px. |
| `favicon/` | `favicon.svg`, `favicon-16.svg`, `favicon.ico` (16/32/48), `apple-touch-icon.png`, and `head-snippet.html` with the tags to paste into the site's `<head>`. |
| `avatar/` | Square profile pictures (dark and light, 400 and 800 px). Platforms crop them to a circle; the mark survives the crop. |

Which mark size: master from 48 px up, `32cut` for 24–47 px, `16cut` for 16–23 px. Never smaller than 16 px.

## 02-colour

| File | For |
|---|---|
| `palette.png`, `palette.txt` | Looking at, and copying hex values into Canva's Brand Kit, Figma or anything else. |
| `tokens.css` | The site's own tokens (OKLCH, light and dark themes). |
| `tailwind-theme.css` | A Tailwind v4 `@theme` block in hex. |
| `tokens.json` | Design tokens (colour, fonts, radii, motion) for Figma Tokens or Style Dictionary. |
| `forthe-tech.ase` | Adobe Swatch Exchange: Illustrator, Photoshop, InDesign, Affinity. |
| `forthe-tech.gpl` | GIMP, Inkscape and Krita palette. |

Rule of thumb: paper and ink carry everything; clay (#A8471B on light, #E67E54 on dark) is for the logo only.

## 03-type

Instrument Serif (titles) and Inter (everything else), full Google Fonts versions as `.ttf`, with their
SIL Open Font Licences. Install them for Word, Keynote, Canva uploads or Figma. `type-scale.md` has the sizes.

## 04-templates

Ready-made PNGs with sample content, sized for where they go:

| File | Where |
|---|---|
| `linkedin-banner-1584x396.png` | LinkedIn profile cover (the left side stays clear for your photo) |
| `post-new-build-1200x1200.png` | Announcing a build (swap the name, line and screenshot) |
| `post-dispatch-quote-1080x1350.png` | A line from an essay |
| `story-1080x1920.png` | Instagram or LinkedIn story |
| `share-card-1200x630.png` | The link-preview card, one per page |
| `video-call-background-1920x1080.png` | Zoom, Meet, Teams |
| `email-signature.html` | Open in a browser, copy, paste into Gmail or Outlook signature settings |

## 05-guidelines

- `forthe.tech-brand-sheet.pdf` / `.png`: the one-page summary
- `forthe.tech-logo-guide.pdf`: the logo, in full (12 pages)
- `forthe.tech-brand-guidelines.pdf`: the whole system (20 pages)

When the kit and the guides disagree, the guides win.
