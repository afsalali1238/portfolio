# forthe.tech type

Two typefaces, both free under the SIL Open Font License (licences in this folder).

| Face | Files | Use |
|---|---|---|
| Instrument Serif | InstrumentSerif-Regular.ttf, InstrumentSerif-Italic.ttf | Titles, names, kickers, pull quotes, the wordmark. One weight only: never bold. |
| Inter | Inter-Regular.ttf, Inter-Italic.ttf, Inter-Medium.ttf, Inter-SemiBold.ttf | Body, buttons, labels, meta. On the web, turn on features ss01 and cv11. |

Install the .ttf files to use them in Word, Keynote, Canva (upload) or Figma. The site loads its own copies through @fontsource.

## Scale (as built on the site)

| Role | Face | Desktop / phone | Leading |
|---|---|---|---|
| Hero display | Instrument Serif | 128 px / 13vw | 0.88 |
| Page title (h1) | Instrument Serif | 72 / 48 px | 1.02 |
| Section title (h2) | Instrument Serif | 60 / 48 px | 1.0 |
| Essay subhead | Instrument Serif | 36 / 30 px | 1.1–1.2 |
| Card title (h3) | Instrument Serif | 36 px | 1.0 |
| Kicker | Instrument Serif italic, ink mute | 20 / 18 px | 1.4 |
| Lead | Inter, ink soft | 18 / 16 px | 1.625 |
| Body | Inter, ink soft | 16 px | 1.625 |
| Interface | Inter 500 | 14 px | 1.4 |
| Meta, caption | Inter, ink mute | 12 px | 1.33 |

Rules: serif for titles, Inter for information. Headline statements end with a full stop. Long reads stay at 60–75 characters a line. Nothing under 12 px.

## For social and slides

| Element | Face | Size at 1080 px wide |
|---|---|---|
| Title | Instrument Serif | 96–140 px |
| Kicker | Inter 500, ink mute | 26–30 px |
| Body | Inter | 32–36 px |
| Footer meta | Inter, ink mute | 24–26 px |
